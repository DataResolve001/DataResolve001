# DataResolve

**DataResolve** is a full-stack project for business forecasting using Motha's Second Law of Probability.

## Stack

- **Frontend**: React + TailwindCSS
- **Backend**: Node.js + Express
- **ML Engine**: Python Flask

## Setup

```bash
chmod +x scripts/unzip_and_run.sh
./scripts/unzip_and_run.sh
```

Then run frontend manually in a new terminal:

```bash
cd frontend
npm run dev
```