const express = require("express");
const cors = require("cors");
const app = express();
const PORT = 5000;

app.use(cors());
app.use(express.json());

app.get("/", (req, res) => res.send("DataResolve backend running"));

app.post("/api/forecast", (req, res) => {
  const { sales } = req.body;
  const avg = sales.reduce((a, b) => a + b, 0) / sales.length;
  res.json({ prediction: avg });
});

app.listen(PORT, () => console.log(`Server running on port ${PORT}`));