#!/bin/bash

echo "Installing backend..."
cd backend
npm install &

echo "Installing frontend..."
cd ../frontend
npm install &

echo "Starting backend..."
cd ../backend
node server.js &

echo "Starting ML engine..."
cd ../ml_engine
pip install flask
python3 app.py &

echo "Done. Start frontend manually in a new terminal with 'cd frontend && npm run dev'"