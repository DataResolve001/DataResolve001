from flask import Flask, request, jsonify

app = Flask(__name__)

@app.route("/predict", methods=["POST"])
def predict():
    data = request.get_json()
    prediction = sum(data.get("sales", [])) / len(data.get("sales", []))
    return jsonify({"prediction": prediction})

if __name__ == "__main__":
    app.run(port=5001)