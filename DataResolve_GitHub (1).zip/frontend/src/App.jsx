import { useState } from "react";

function App() {
  const [data, setData] = useState(null);

  const handleClick = async () => {
    const res = await fetch("http://localhost:5000/api/forecast", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ sales: [100, 200, 300] }),
    });
    const result = await res.json();
    setData(result);
  };

  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold">DataResolve Forecast</h1>
      <button onClick={handleClick} className="mt-4 bg-blue-600 text-white px-4 py-2 rounded">
        Forecast Sales
      </button>
      {data && <pre className="mt-4">{JSON.stringify(data, null, 2)}</pre>}
    </div>
  );
}

export default App;